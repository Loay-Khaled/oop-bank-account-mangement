public interface CustomerDetails {
    String getName();
    String getCustomerId();
}
